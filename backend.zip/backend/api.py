import os
import json
import asyncio
from datetime import datetime, timedelta
import httpx
import sqlite3
from fastapi import FastAPI, WebSocket, WebSocketDisconnect, HTTPException
from fastapi.responses import JSONResponse, StreamingResponse
from pydantic import BaseModel
from typing import List, Optional, Dict, Any, Literal, Generator
from contextlib import asynccontextmanager
from db import init_db, seed_history
from simulator import SmartHomeSimulator
from llm_connector import llm_invoke
from reportlab.lib.pagesizes import letter
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak
from reportlab.lib import colors
import io

# FastAPI app with lifespan that initializes DB and simulator
@asynccontextmanager
async def lifespan(app: FastAPI):
    init_db()
    seed_history()
    global simulator
    simulator = SmartHomeSimulator()
    yield

app = FastAPI(title="Energy Detective AI Backend", lifespan=lifespan)

class UserConfig(BaseModel): appliances: List[str]
class UserGoals(BaseModel): kw_limit_threshold: float; monthly_kwh_goal: float
class ActionRequest(BaseModel): baseline_forecast: List[Dict]; suggestion_id: str; affected_appliance: str
class ActionCommit(BaseModel): action_title: str; savings_inr: float
class LeaderboardEntry(BaseModel): rank: int; name: str; monthly_cost_inr: float; is_user: bool
class UserActionLog(BaseModel): id: int; action_title: str; timestamp: str; savings_inr: float
class ChatMessage(BaseModel): message: str

async def call_llm(prompt: str) -> Any:
    # Use the synchronous llm_invoke in an async context
    # If needed, run in a thread pool for true async
    import asyncio
    loop = asyncio.get_event_loop()
    return await loop.run_in_executor(None, llm_invoke, prompt)

@app.websocket("/ws/live-meter")
async def websocket_endpoint(websocket: WebSocket):
    await websocket.accept()
    conn = sqlite3.connect('energy.db')
    try:
        while True:
            data = simulator.get_instant_reading()
            hour = data['hour']
            rate = 12.0 if 18 <= hour <= 22 else 8.0 
            cost = round(data["total_kw"] * rate, 2)
            data["cost_per_hour"] = cost
            conn.execute("INSERT INTO consumption_history (timestamp, total_kw, cost, temperature) VALUES (?, ?, ?, ?)", 
                         (data['timestamp'], data['total_kw'], cost, data['temperature_c']))
            conn.commit()
            if data["total_kw"] > simulator.kw_alert_limit:
                data["alert"] = f"⚠️ WARNING: Load ({data['total_kw']} kW) exceeded limit ({simulator.kw_alert_limit} kW)!"
            await websocket.send_text(json.dumps(data))
            await asyncio.sleep(2)
    except WebSocketDisconnect: print("Client Disconnected")
    finally: conn.close()

@app.get("/history/data")
def get_history_data(period: Literal['day', 'week', 'month'] = 'day'):
    conn = sqlite3.connect('energy.db')
    cursor = conn.cursor()
    if period == 'day':
        query = """
            SELECT strftime('%Y-%m-%dT%H:00:00', timestamp) as hour_bucket, AVG(total_kw), SUM(cost)
            FROM consumption_history
            WHERE timestamp >= datetime('now', '-1 day')
            GROUP BY hour_bucket
            ORDER BY hour_bucket ASC
        """
    elif period == 'week':
        query = """
            SELECT date(timestamp) as day_bucket, AVG(total_kw)*24, SUM(cost)*24
            FROM consumption_history
            WHERE timestamp >= datetime('now', '-7 days')
            GROUP BY day_bucket
            ORDER BY day_bucket ASC
        """
    else:
        query = """
            SELECT date(timestamp) as day_bucket, AVG(total_kw)*24, SUM(cost)*24
            FROM consumption_history
            WHERE timestamp >= datetime('now', '-30 days')
            GROUP BY day_bucket
            ORDER BY day_bucket ASC
        """
    cursor.execute(query)
    rows = cursor.fetchall()
    conn.close()
    return {
        "period": period,
        "labels": [r[0] for r in rows],
        "kwh_data": [round(r[1], 2) for r in rows],
        "cost_data": [round(r[2], 2) for r in rows]
    }

@app.post("/config/appliances")
def configure_home(config: UserConfig):
    simulator.set_user_appliances(config.appliances)
    return {"status": "updated", "appliances": simulator.active_appliances}

@app.post("/config/goals")
def set_user_goals(goals: UserGoals):
    conn = sqlite3.connect('energy.db')
    conn.execute("INSERT OR REPLACE INTO user_goals (user_id, kw_limit_threshold, monthly_kwh_goal) VALUES ('default_user', ?, ?)", (goals.kw_limit_threshold, goals.monthly_kwh_goal))
    conn.commit()
    conn.close()
    simulator.kw_alert_limit = goals.kw_limit_threshold
    return {"status": "updated", "goals": goals.dict()}

@app.get("/analyze/budget_plan")
async def get_budget_plan():
    conn = sqlite3.connect('energy.db')
    row = conn.execute("SELECT monthly_kwh_goal FROM user_goals WHERE user_id='default_user'").fetchone()
    conn.close()
    target_kwh = row[0] if row else 300.0
    appliances = simulator.active_appliances
    projected_daily = 10.0 + (len(appliances) * 1.5) 
    projected_monthly = projected_daily * 30
    gap = projected_monthly - target_kwh
    if gap <= 0:
        return {"status": "on_track", "message": f"Projected {int(projected_monthly)} kWh < Goal {target_kwh} kWh.", "actions": []}
    prompt = f"""
    User Goal: {target_kwh} kWh/month. Projected: {int(projected_monthly)}. Gap: {int(gap)}.
    Appliances: {', '.join(appliances)}.
    Task: Generate 3 specific actions to save {int(gap)} kWh/month.
    Output JSON list: [{{ "id": "s1", "suggestion_id": "x", "title": "Step 1", "kwh_save_monthly": 10, "affected_appliance": "AC" }}]
    """
    plan = await call_llm(prompt)
    return {"status": "over_budget", "gap_kwh": int(gap), "plan_steps": plan}

@app.get("/config/options")
def get_available_appliances(): return list(simulator.library.keys())

@app.get("/analyze/suggestions")
async def get_suggestions():
    reading = simulator.get_instant_reading()
    prompt = f"""
    You are an Energy Auditor.
    Context: 
    - Load: {reading['total_kw']} kW 
    - Time: {reading['hour']}:00
    - Weather: {reading['temperature_c']}°C, {reading['weather_condition']}
    - Appliances: {', '.join(simulator.active_appliances)}
    
    Task: Suggest 2 actions. 
    IMPORTANT: Use the weather context. 
    - If it's hot ({reading['temperature_c']}C) and Sunny, suggest closing blinds or optimizing AC.
    - If cold, suggest heater optimizations.
    
    Output JSON: [{{ "id": "turn_off_ac", "title": "Turn Off AC", "message": "...", "severity": "high", "affected_appliance": "AC" }}]
    """
    return await call_llm(prompt)

@app.get("/forecast/baseline")
async def get_baseline_forecast():
    appliances = simulator.active_appliances
    weather_info = f"Avg Temp {simulator.current_temp}°C"
    prompt = f"""
    Generate 24h forecast (Hourly kW) for: {', '.join(appliances)}. {weather_info}.
    Pricing: Peak (18-22h) 12 INR, Off-peak 8 INR.
    Output JSON list (0-23h): [{{ "hour": "00:00", "load_kw": 0.5, "cost": 4.0 }}]
    """
    forecast = await call_llm(prompt)
    if forecast and isinstance(forecast, list):
        monthly = sum(i.get('cost', 0) for i in forecast) * 30
        conn = sqlite3.connect('energy.db')
        conn.execute("UPDATE leaderboard SET monthly_score = ? WHERE user_id = 'default_user'", (int(monthly),))
        conn.commit()
        conn.close()
    return forecast

@app.post("/forecast/simulate_action")
async def simulate_action_impact(request: ActionRequest):
    prompt = f"""
    Baseline: {json.dumps(request.baseline_forecast[:3])}...
    Action: "{request.suggestion_id}" on "{request.affected_appliance}".
    Task: Reduce load_kw in relevant hours. Return modified 24h JSON list.
    """
    new_forecast = await call_llm(prompt)
    # Handle AIMessage or other wrapper types
    if hasattr(new_forecast, 'content'):
        import re
        import json as _json
        # Try to extract JSON from content
        match = re.search(r'```json\s*([\s\S]*?)```', new_forecast.content)
        if match:
            try:
                new_forecast = _json.loads(match.group(1))
            except Exception:
                new_forecast = []
        else:
            try:
                new_forecast = _json.loads(new_forecast.content)
            except Exception:
                new_forecast = []
    if new_forecast and isinstance(new_forecast[0], tuple):
        keys = request.baseline_forecast[0].keys() if request.baseline_forecast else []
        new_forecast = [dict(zip(keys, tup)) for tup in new_forecast]
    old_cost = sum(i.get('cost', 0) for i in request.baseline_forecast)
    new_cost = sum(i.get('cost', 0) for i in new_forecast)
    return {
        "modified_forecast": new_forecast,
        "savings_summary": {
            "original_daily_cost": round(old_cost, 2),
            "new_daily_cost": round(new_cost, 2),
            "total_savings_amount": round(old_cost - new_cost, 2)
        }
    }

@app.post("/actions/commit")
def commit_action(action: ActionCommit):
    conn = sqlite3.connect('energy.db')
    conn.execute("INSERT INTO action_log (action_title, timestamp, savings_inr) VALUES (?, ?, ?)", (action.action_title, datetime.now().isoformat(), action.savings_inr))
    conn.commit()
    conn.close()
    return {"status": "committed", "message": f"Saved ₹{action.savings_inr}"}

@app.get("/actions/history")
def get_action_history():
    conn = sqlite3.connect('energy.db')
    rows = conn.execute("SELECT id, action_title, timestamp, savings_inr FROM action_log ORDER BY id DESC LIMIT 20").fetchall()
    conn.close()
    return [{"id": r[0], "action_title": r[1], "timestamp": r[2], "savings_inr": r[3]} for r in rows]

@app.get("/gamification/leaderboard")
def get_leaderboard():
    conn = sqlite3.connect('energy.db')
    rows = conn.execute("SELECT display_name, monthly_score, is_bot FROM leaderboard ORDER BY monthly_score ASC").fetchall()
    conn.close()
    return [{"rank": i+1, "name": r[0], "monthly_cost_inr": r[1], "is_user": r[2]==0} for i, r in enumerate(rows)]

@app.get("/analyze/solar_potential")
def get_solar_potential():
    conn = sqlite3.connect('energy.db')
    row = conn.execute("SELECT monthly_score FROM leaderboard WHERE user_id='default_user'").fetchone()
    conn.close()
    monthly_bill = row[0] if row else 3000
    avg_daily_kwh = (monthly_bill / 8.0) / 30.0
    weather_factor = 0.6 if simulator.weather_condition in ["Cloudy", "Rainy"] else 1.0
    needed_generation = avg_daily_kwh * 0.9
    system_size_kw = round(needed_generation / (4.0 * weather_factor), 1)
    return {
        "current_monthly_bill": monthly_bill,
        "recommended_system_kw": system_size_kw,
        "weather_adjustment": f"Adjusted for {simulator.weather_condition} weather",
        "installation_cost": system_size_kw * 50000,
        "annual_savings_inr": round((needed_generation * 8.0) * 365, 0)
    }

@app.get("/report/download")
def download_report():
    conn = sqlite3.connect('energy.db')
    score = conn.execute("SELECT monthly_score FROM leaderboard WHERE user_id='default_user'").fetchone()[0]
    conn.close()
    report = f"ENERGY DETECTIVE REPORT\nDate: {datetime.now()}\nTotal Monthly Cost: ₹{score}\nWeather: {simulator.current_temp}°C"
    return JSONResponse({"report_text": report})

@app.get("/guide")
def get_user_guide():
    return {
        "title": "Energy Detective User Guide",
        "sections": [
            {"heading": "1. Live Dashboard", "content": "Monitor real-time consumption. Red alerts appear if you cross your KW limit."},
            {"heading": "2. Budget Planner", "content": "Set a monthly target (e.g. 300 units). The AI will generate a step-by-step checklist to hit that goal."},
            {"heading": "3. Action Simulator", "content": "Click 'Simulate' on any suggestion to see how your forecast graph changes instantly."}
        ]
    }

# ==========================================
# PART 3: CHAT & REPORT GENERATION
# ==========================================

def get_user_consumption_data(days: int = 30) -> Dict[str, Any]:
    """Fetch user consumption data from database"""
    conn = sqlite3.connect('energy.db')
    cursor = conn.cursor()
    
    # Get consumption summary
    cursor.execute(f"""
        SELECT 
            COUNT(*) as readings,
            AVG(total_kw) as avg_kw,
            MAX(total_kw) as max_kw,
            MIN(total_kw) as min_kw,
            SUM(cost) as total_cost
        FROM consumption_history
        WHERE timestamp >= datetime('now', '-{days} days')
    """)
    row = cursor.fetchone()
    consumption_summary = {
        "readings": row[0],
        "avg_kw": round(row[1], 2) if row[1] else 0,
        "max_kw": round(row[2], 2) if row[2] else 0,
        "min_kw": round(row[3], 2) if row[3] else 0,
        "total_cost": round(row[4], 2) if row[4] else 0
    }
    
    # Get user goals
    cursor.execute("SELECT kw_limit_threshold, monthly_kwh_goal FROM user_goals WHERE user_id='default_user'")
    goals_row = cursor.fetchone()
    goals = {
        "kw_limit": goals_row[0] if goals_row else 5.0,
        "monthly_goal": goals_row[1] if goals_row else 300.0
    }
    
    # Get active appliances
    cursor.execute("SELECT appliance_name FROM user_config WHERE user_id='default_user'")
    appliances = [row[0] for row in cursor.fetchall()]
    
    # Get recent actions
    cursor.execute("""
        SELECT action_title, savings_inr FROM action_log 
        WHERE user_id='default_user' 
        ORDER BY timestamp DESC LIMIT 10
    """)
    actions = [{"title": row[0], "savings": row[1]} for row in cursor.fetchall()]
    
    conn.close()
    
    return {
        "consumption": consumption_summary,
        "goals": goals,
        "appliances": appliances,
        "recent_actions": actions,
        "current_temp": simulator.current_temp,
        "weather": simulator.weather_condition
    }

@app.post("/chat/message")
async def chat_with_data(chat: ChatMessage):
    """Chat endpoint that processes user queries against their energy data"""
    try:
        user_message = chat.message.lower()
        # Only include user data context if user asks for it
        keywords = ["my data", "my usage", "my consumption", "my bill", "my appliances", "my history", "my report"]
        if any(kw in user_message for kw in keywords):
            user_data = get_user_consumption_data(30)
            prompt = f"""
            You are an Energy Advisor AI. The user has asked the following question about their energy consumption:
            \"{chat.message}\"
            Here is their energy data context:
            - Average Load: {user_data['consumption']['avg_kw']} kW
            - Peak Load: {user_data['consumption']['max_kw']} kW
            - Total Cost (30 days): ₹{user_data['consumption']['total_cost']}
            - Monthly Goal: {user_data['goals']['monthly_goal']} kWh
            - Active Appliances: {', '.join(user_data['appliances'])}
            - Current Temperature: {user_data['current_temp']}°C
            - Weather: {user_data['weather']}
            - Recent Actions Applied: {len(user_data['recent_actions'])} optimizations
            Provide a helpful, data-driven response. Be specific and actionable.
            """
        else:
            prompt = chat.message
        response = await call_llm(prompt)
        response_text = response
        if hasattr(response, 'content'):
            response_text = response.content
        return {"reply": response_text}
    except Exception as e:
        return {"reply": f"Error processing query: {str(e)}"}

@app.post("/chat/stream")
async def chat_stream(chat: ChatMessage):
    """Streaming chat endpoint for real-time responses"""
    async def event_generator() -> Generator:
        try:
            user_data = get_user_consumption_data(30)
            prompt = f"""
            You are an Energy Advisor AI. The user has asked:
            "{chat.message}"
            
            Energy Context:
            - Avg Load: {user_data['consumption']['avg_kw']} kW
            - Peak Load: {user_data['consumption']['max_kw']} kW
            - Cost (30d): ₹{user_data['consumption']['total_cost']}
            - Monthly Goal: {user_data['goals']['monthly_goal']} kWh
            - Appliances: {', '.join(user_data['appliances'])}
            - Temp: {user_data['current_temp']}°C, {user_data['weather']}
            
            Provide a helpful response.
            """
            
            response = await call_llm(prompt)
            response_text = response.content if hasattr(response, 'content') else str(response)
            
            # Stream response character by character
            for char in response_text:
                yield f"data: {json.dumps({'chunk': char})}\n\n"
                await asyncio.sleep(0.01)  # Small delay for streaming effect
            
            yield f"data: {json.dumps({'done': True})}\n\n"
        except Exception as e:
            yield f"data: {json.dumps({'error': str(e)})}\n\n"
    
    return StreamingResponse(event_generator(), media_type="text/event-stream")

def generate_pdf_report() -> bytes:
    """Generate a comprehensive PDF report of energy consumption"""
    try:
        from reportlab.lib.pagesizes import letter
        from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
        from reportlab.lib.units import inch
        from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak
        from reportlab.lib import colors
    except ImportError:
        # Fallback if reportlab not installed
        return None
    
    buffer = io.BytesIO()
    doc = SimpleDocTemplate(buffer, pagesize=letter)
    elements = []
    styles = getSampleStyleSheet()
    
    # Custom styles
    title_style = ParagraphStyle(
        'CustomTitle',
        parent=styles['Heading1'],
        fontSize=24,
        textColor=colors.HexColor('#1E40AF'),
        spaceAfter=30,
        alignment=1
    )
    
    heading_style = ParagraphStyle(
        'CustomHeading',
        parent=styles['Heading2'],
        fontSize=14,
        textColor=colors.HexColor('#1F2937'),
        spaceAfter=12,
        spaceBefore=12
    )
    
    # Get data
    user_data = get_user_consumption_data(30)
    conn = sqlite3.connect('energy.db')
    cursor = conn.cursor()
    cursor.execute("SELECT display_name FROM leaderboard WHERE user_id='default_user'")
    user_row = cursor.fetchone()
    user_name = user_row[0] if user_row else "User"
    conn.close()
    
    # Title
    elements.append(Paragraph("ENERGY DETECTIVE REPORT", title_style))
    elements.append(Paragraph(f"Generated on {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}", styles['Normal']))
    elements.append(Spacer(1, 0.3*inch))
    
    # User Info
    elements.append(Paragraph("User Information", heading_style))
    user_info_data = [
        ['Metric', 'Value'],
        ['User Name', user_name],
        ['Report Period', 'Last 30 Days'],
        ['Generated Date', datetime.now().strftime('%Y-%m-%d %H:%M:%S')]
    ]
    user_table = Table(user_info_data, colWidths=[2.5*inch, 3*inch])
    user_table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#1E40AF')),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
        ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('FONTSIZE', (0, 0), (-1, 0), 12),
        ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
        ('GRID', (0, 0), (-1, -1), 1, colors.grey)
    ]))
    elements.append(user_table)
    elements.append(Spacer(1, 0.3*inch))
    
    # Consumption Summary
    elements.append(Paragraph("Energy Consumption Summary", heading_style))
    consumption_data = [
        ['Metric', 'Value'],
        ['Average Load', f"{user_data['consumption']['avg_kw']} kW"],
        ['Peak Load', f"{user_data['consumption']['max_kw']} kW"],
        ['Minimum Load', f"{user_data['consumption']['min_kw']} kW"],
        ['Total Cost (30d)', f"₹{user_data['consumption']['total_cost']}"],
        ['Data Points Recorded', f"{user_data['consumption']['readings']} readings"]
    ]
    consumption_table = Table(consumption_data, colWidths=[2.5*inch, 3*inch])
    consumption_table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#10B981')),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
        ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('FONTSIZE', (0, 0), (-1, 0), 12),
        ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
        ('GRID', (0, 0), (-1, -1), 1, colors.grey)
    ]))
    elements.append(consumption_table)
    elements.append(Spacer(1, 0.3*inch))
    
    # Goals & Status
    elements.append(Paragraph("Energy Goals & Status", heading_style))
    goals_data = [
        ['Goal', 'Target', 'Status'],
        ['Monthly kWh Goal', f"{user_data['goals']['monthly_goal']} kWh", '✓ On Track'],
        ['Load Threshold', f"{user_data['goals']['kw_limit']} kW", '✓ Compliant']
    ]
    goals_table = Table(goals_data, colWidths=[2*inch, 2*inch, 2.5*inch])
    goals_table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#F59E0B')),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
        ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('FONTSIZE', (0, 0), (-1, 0), 12),
        ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
        ('GRID', (0, 0), (-1, -1), 1, colors.grey)
    ]))
    elements.append(goals_table)
    elements.append(Spacer(1, 0.3*inch))
    
    # Active Appliances
    elements.append(Paragraph("Active Appliances", heading_style))
    appliance_data = [['Appliance']] + [[app] for app in user_data['appliances']]
    appliance_table = Table(appliance_data, colWidths=[5.5*inch])
    appliance_table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#8B5CF6')),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
        ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('FONTSIZE', (0, 0), (-1, 0), 12),
        ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
        ('GRID', (0, 0), (-1, -1), 1, colors.grey)
    ]))
    elements.append(appliance_table)
    elements.append(Spacer(1, 0.3*inch))
    
    # Recent Actions
    if user_data['recent_actions']:
        elements.append(Paragraph("Recent Optimizations Applied", heading_style))
        actions_data = [['Action', 'Savings (₹)']] + [[act['title'], f"₹{act['savings']}"] for act in user_data['recent_actions']]
        actions_table = Table(actions_data, colWidths=[3.5*inch, 2*inch])
        actions_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#06B6D4')),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
            ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, 0), 12),
            ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
            ('GRID', (0, 0), (-1, -1), 1, colors.grey)
        ]))
        elements.append(actions_table)
        elements.append(Spacer(1, 0.3*inch))
    
    # Footer
    elements.append(Spacer(1, 0.2*inch))
    elements.append(Paragraph("Energy Detective AI - Your Smart Energy Management Partner", styles['Normal']))
    
    doc.build(elements)
    buffer.seek(0)
    return buffer.getvalue()

@app.get("/report/generate-pdf")
async def generate_report_pdf():
    """Generate and download PDF report"""
    try:
        pdf_bytes = generate_pdf_report()
        if not pdf_bytes:
            return JSONResponse(
                {"error": "PDF generation library not installed. Install reportlab: pip install reportlab"},
                status_code=400
            )
        return StreamingResponse(
            iter([pdf_bytes]),
            media_type="application/pdf",
            headers={"Content-Disposition": "attachment; filename=energy_report.pdf"}
        )
    except Exception as e:
        return JSONResponse({"error": str(e)}, status_code=500)

@app.get("/report/download-enhanced")
async def download_enhanced_report():
    """Enhanced JSON report with LLM insights"""
    try:
        user_data = get_user_consumption_data(30)
        
        # Generate LLM insights
        prompt = f"""
        Based on this user's energy consumption data, provide 3-5 brief, actionable insights:
        - Avg Load: {user_data['consumption']['avg_kw']} kW
        - Peak Load: {user_data['consumption']['max_kw']} kW
        - Total Cost: ₹{user_data['consumption']['total_cost']} (30 days)
        - Appliances: {', '.join(user_data['appliances'])}
        - Current Temp: {user_data['current_temp']}°C
        
        Format as a bulleted list of recommendations.
        """
        
        insights = await call_llm(prompt)
        insights_text = insights.content if hasattr(insights, 'content') else str(insights)
        
        return {
            "user_data": user_data,
            "ai_insights": insights_text,
            "generated_at": datetime.now().isoformat(),
            "period_days": 30
        }
    except Exception as e:
        return JSONResponse({"error": str(e)}, status_code=500)
