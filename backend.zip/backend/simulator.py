import random
import math
from datetime import datetime
import sqlite3
from typing import List
from db import DB_NAME

class Appliance:
    def __init__(self, name, watts, probability, duration_mins, is_cyclic=False):
        self.name = name
        self.watts = watts
        self.probability = probability
        self.duration_mins = duration_mins
        self.is_cyclic = bool(is_cyclic)
        self.current_state = False
        self.timer = 0

    def tick(self, current_hour, current_temp):
        if self.current_state:
            self.timer -= 1
            if self.timer <= 0: self.current_state = False
            return self.watts * random.uniform(0.95, 1.05)

        is_peak = (7 <= current_hour <= 9) or (18 <= current_hour <= 22)
        weather_modifier = 1.0
        if self.name == "AC":
            if current_temp > 30: weather_modifier = 5.0
            elif current_temp > 25: weather_modifier = 3.0
            elif current_temp < 20: weather_modifier = 0.0
        if self.name == "Heater":
            if current_temp < 10: weather_modifier = 5.0
            elif current_temp < 18: weather_modifier = 3.0
            elif current_temp > 22: weather_modifier = 0.0

        hourly_modifier = 2.5 if is_peak else 0.2
        chance = self.probability * hourly_modifier * weather_modifier
        if self.is_cyclic: chance = 0.1

        if random.random() < chance:
            self.current_state = True
            self.timer = self.duration_mins
            return self.watts
        return 0.0

class SmartHomeSimulator:
    def __init__(self, seed_mode=False):
        self.library = {}
        self.active_appliances = []
        self.current_temp = 25.0
        self.weather_condition = "Sunny"
        self.kw_alert_limit = 5.0 

        self.load_library_from_db()
        if not seed_mode:
            self.load_user_config_from_db()
            self.load_goals_from_db()
        else:
            self.active_appliances = ["Fridge", "TV", "AC", "WashingMachine", "Router"]

    def load_library_from_db(self):
        conn = sqlite3.connect(DB_NAME)
        cursor = conn.cursor()
        cursor.execute('SELECT * FROM master_appliances')
        for row in cursor.fetchall():
            self.library[row[0]] = Appliance(*row)
        conn.close()

    def load_user_config_from_db(self):
        conn = sqlite3.connect(DB_NAME)
        cursor = conn.cursor()
        cursor.execute("SELECT appliance_name FROM user_config WHERE user_id='default_user'")
        rows = cursor.fetchall()
        if rows: self.active_appliances = [row[0] for row in rows if row[0] in self.library]
        else: self.active_appliances = ["Fridge", "TV", "WashingMachine", "LEDBulb", "Router", "AC"]
        if "Fridge" not in self.active_appliances: self.active_appliances.append("Fridge")
        conn.close()

    def load_goals_from_db(self):
        conn = sqlite3.connect(DB_NAME)
        cursor = conn.cursor()
        cursor.execute("SELECT kw_limit_threshold FROM user_goals WHERE user_id='default_user'")
        row = cursor.fetchone()
        if row: self.kw_alert_limit = row[0]
        conn.close()

    def set_user_appliances(self, appliance_names: List[str]):
        conn = sqlite3.connect(DB_NAME)
        cursor = conn.cursor()
        cursor.execute("DELETE FROM user_config WHERE user_id='default_user'")
        valid_apps = [name for name in appliance_names if name in self.library]
        data = [('default_user', name) for name in valid_apps]
        if data: cursor.executemany("INSERT INTO user_config VALUES (?, ?)", data)
        conn.commit()
        conn.close()
        self.load_user_config_from_db()

    def calculate_temp(self, hour):
        base_temp = 22
        variation = 8
        temp = base_temp + variation * math.sin((hour - 9) * math.pi / 12)
        return temp + random.uniform(-1, 1)

    def simulate_historical_tick(self, hour):
        """Helper for seeding history"""
        temp = self.calculate_temp(hour)
        total_watts = 0
        for name in self.active_appliances:
            app = self.library[name]
            is_peak = (7 <= hour <= 9) or (18 <= hour <= 22)
            w_mod = 1.0
            if name == "AC" and temp > 25: w_mod = 3.0
            chance = app.probability * (2.5 if is_peak else 0.2) * w_mod
            if app.is_cyclic: chance = 0.5
            if random.random() < chance:
                total_watts += app.watts

        total_watts += random.uniform(30, 80)
        total_kw = round(total_watts / 1000, 3)
        rate = 12.0 if (18 <= hour <= 22) else 8.0
        return {"total_kw": total_kw, "cost": round(total_kw * rate, 2), "temp": round(temp, 1)}

    def get_instant_reading(self):
        current_hour = datetime.now().hour
        self.current_temp = self.calculate_temp(current_hour)
        if random.random() < 0.1: self.weather_condition = "Cloudy"
        elif random.random() < 0.05: self.weather_condition = "Rainy"
        else: self.weather_condition = "Sunny"
        total_watts = 0
        active_now = []
        for name in self.active_appliances:
            app = self.library[name]
            watts = app.tick(current_hour, self.current_temp)
            if watts > 0:
                total_watts += watts
                active_now.append(name)
        total_watts += random.uniform(30, 80)
        total_kw = round(total_watts / 1000, 3)
        return {
            "timestamp": datetime.now().isoformat(),
            "total_kw": total_kw,
            "hour": current_hour,
            "temperature_c": round(self.current_temp, 1),
            "weather_condition": self.weather_condition,
            "active_devices_debug": active_now 
        }
