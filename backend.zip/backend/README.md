# Energy Detective AI Backend

This backend powers the Energy Detective application, providing real-time energy monitoring, budget planning, action simulation, gamification, and LLM-powered suggestions. It is built with FastAPI and integrates with a React frontend via REST and WebSocket endpoints.

---

## Table of Contents
- [Setup & Installation](#setup--installation)
- [Environment Variables](#environment-variables)
- [Project Structure](#project-structure)
- [API Endpoints](#api-endpoints)
  - [WebSocket: Live Meter](#websocket-live-meter)
  - [GET /history/data](#get-historydata)
  - [POST /config/appliances](#post-configappliances)
  - [POST /config/goals](#post-configgoals)
  - [GET /analyze/budget_plan](#get-analyzebudget_plan)
  - [GET /config/options](#get-configoptions)
  - [GET /analyze/suggestions](#get-analyzesuggestions)
  - [GET /forecast/baseline](#get-forecastbaseline)
  - [POST /forecast/simulate_action](#post-forecastsimulate_action)
  - [POST /actions/commit](#post-actionscommit)
  - [GET /actions/history](#get-actionshistory)
  - [GET /gamification/leaderboard](#get-gamificationleaderboard)
  - [GET /analyze/solar_potential](#get-analyzesolar_potential)
  - [GET /report/download](#get-reportdownload)
  - [GET /guide](#get-guide)
  - [POST /chat/message](#post-chatmessage)
  - [POST /chat/stream](#post-chatstream)
  - [GET /report/generate-pdf](#get-reportgenerate-pdf)
  - [GET /report/download-enhanced](#get-reportdownload-enhanced)
- [LLM Integration](#llm-integration)
- [Frontend Integration Guide](#frontend-integration-guide)
- [New Features](#new-features)

---

## Setup & Installation

1. **Clone the repository** and navigate to the backend folder:
   ```powershell
   cd backend
   ```
2. **Install dependencies** (recommended: use a virtual environment):
   ```powershell
   pip install fastapi uvicorn httpx pydantic python-dotenv langchain-openai reportlab
   ```
3. **Configure environment variables** in `.env`:
   - See [Environment Variables](#environment-variables)
4. **Run the backend server**:
   ```powershell
   python main.py
   ```
   Or directly with uvicorn:
   ```powershell
   uvicorn api:app --reload --host 0.0.0.0 --port 8000
   ```

---

## Environment Variables

Create a `.env` file in the backend directory with:
```
OPENAI_API_KEY=your_api_key_here
OPENAI_BASE_URL=https://genailab.tcs.in
OPENAI_MODEL=azure_ai/genailab-maas-DeepSeek-V3-0324
```

---

## Project Structure

```
backend/
  api.py            # FastAPI endpoints
  db.py             # Database schema & seed logic
  simulator.py      # Appliance & simulation logic
  llm_connector.py  # LLM integration (LangChain)
  main.py           # App launcher
  README.md         # This file
  .env              # Environment variables
energy.db           # SQLite database
```

---

## API Endpoints

### WebSocket: Live Meter
**Endpoint:** `/ws/live-meter`
- **Type:** WebSocket
- **Description:** Streams real-time energy readings every 2 seconds.
- **Message Format:**
```json
{
  "timestamp": "2025-11-28T12:34:56.789Z",
  "total_kw": 2.45,
  "hour": 12,
  "temperature_c": 27.1,
  "weather_condition": "Sunny",
  "active_devices_debug": ["Fridge", "AC"],
  "cost_per_hour": 19.6,
  "alert": "⚠️ WARNING: Load (2.45 kW) exceeded limit (2.0 kW)!" // Optional
}
```

### GET /history/data
**Query Params:** `period=day|week|month` (default: day)
- **Response:**
```json
{
  "period": "day",
  "labels": ["2025-11-28T01:00:00", ...],
  "kwh_data": [2.1, ...],
  "cost_data": [16.8, ...]
}
```

### POST /config/appliances
**Request Body:**
```json
{
  "appliances": ["Fridge", "AC", "TV"]
}
```
**Response:**
```json
{
  "status": "updated",
  "appliances": ["Fridge", "AC", "TV"]
}
```

### POST /config/goals
**Request Body:**
```json
{
  "kw_limit_threshold": 5.0,
  "monthly_kwh_goal": 300.0
}
```
**Response:**
```json
{
  "status": "updated",
  "goals": {
    "kw_limit_threshold": 5.0,
    "monthly_kwh_goal": 300.0
  }
}
```

### GET /analyze/budget_plan
**Response:**
```json
{
  "status": "over_budget",
  "gap_kwh": 45,
  "plan_steps": [
    {
      "id": "s1",
      "suggestion_id": "x",
      "title": "Step 1",
      "kwh_save_monthly": 10,
      "affected_appliance": "AC"
    }
  ]
}
```
Or if on track:
```json
{
  "status": "on_track",
  "message": "Projected 295 kWh < Goal 300 kWh.",
  "actions": []
}
```

### GET /config/options
**Response:**
```json
["Fridge", "AC", "TV", ...]
```

### GET /analyze/suggestions
**Response:**
```json
[
  {
    "id": "turn_off_ac",
    "title": "Turn Off AC",
    "message": "Reduce AC usage during peak hours.",
    "severity": "high",
    "affected_appliance": "AC"
  }
]
```

### GET /forecast/baseline
**Response:**
```json
[
  { "hour": "00:00", "load_kw": 0.5, "cost": 4.0 },
  ...
]
```

### POST /forecast/simulate_action
**Request Body:**
```json
{
  "baseline_forecast": [ ... ],
  "suggestion_id": "turn_off_ac",
  "affected_appliance": "AC"
}
```
**Response:**
```json
{
  "modified_forecast": [ ... ],
  "savings_summary": {
    "original_daily_cost": 120.0,
    "new_daily_cost": 110.0,
    "total_savings_amount": 10.0
  }
}
```

### POST /actions/commit
**Request Body:**
```json
{
  "action_title": "Turn Off AC",
  "savings_inr": 10.0
}
```
**Response:**
```json
{
  "status": "committed",
  "message": "Saved ₹10.0"
}
```

### GET /actions/history
**Response:**
```json
[
  {
    "id": 1,
    "action_title": "Turn Off AC",
    "timestamp": "2025-11-28T12:34:56.789Z",
    "savings_inr": 10.0
  },
  ...
]
```

### GET /gamification/leaderboard
**Response:**
```json
[
  {
    "rank": 1,
    "name": "GreenGuru_99",
    "monthly_cost_inr": 250,
    "is_user": false
  },
  {
    "rank": 5,
    "name": "You",
    "monthly_cost_inr": 300,
    "is_user": true
  }
]
```

### GET /analyze/solar_potential
**Response:**
```json
{
  "current_monthly_bill": 3000,
  "recommended_system_kw": 2.5,
  "weather_adjustment": "Adjusted for Sunny weather",
  "installation_cost": 125000,
  "annual_savings_inr": 73000
}
```

### GET /report/download
**Response:**
```json
{
  "report_text": "ENERGY DETECTIVE REPORT\nDate: 2025-11-28 12:34:56.789123\nTotal Monthly Cost: ₹300\nWeather: 27.1°C"
}
```

### GET /guide
**Response:**
```json
{
  "title": "Energy Detective User Guide",
  "sections": [
    {
      "heading": "1. Live Dashboard",
      "content": "Monitor real-time consumption. Red alerts appear if you cross your KW limit."
    },
    {
      "heading": "2. Budget Planner",
      "content": "Set a monthly target (e.g. 300 units). The AI will generate a step-by-step checklist to hit that goal."
    },
    {
      "heading": "3. Action Simulator",
      "content": "Click 'Simulate' on any suggestion to see how your forecast graph changes instantly."
    }
  ]
}
```

### POST /chat/message
Chat with your energy data using LLM. Returns a context-aware response.
- **Request Body:**
```json
{ "message": "How can I save more on my bill?" }
```
- **Response:**
```json
{ "reply": "Based on your average load..." }
```

### POST /chat/stream
Real-time streaming chat response (SSE). Returns response chunk by chunk.
- **Request Body:**
```json
{ "message": "What is my peak usage?" }
```
- **Response:**
```
(data: {"chunk": "B"}\n\n ... data: {"done": true}\n\n)
```

### GET /report/generate-pdf
Download a comprehensive PDF report of your energy data.
- **Response:**
  - Content-Type: application/pdf
  - Attachment: energy_report.pdf

### GET /report/download-enhanced
Get a JSON report with user data and LLM-generated insights.
- **Response:**
```json
{
  "user_data": { ... },
  "ai_insights": "- Reduce AC usage...\n- Switch to LED bulbs...",
  "generated_at": "2025-11-28T12:34:56.789Z",
  "period_days": 30
}
```

---

## LLM Integration
- The backend uses LangChain and OpenAI-compatible API for advanced suggestions and forecasting.
- Configure your API key and endpoint in `.env`.
- See `llm_connector.py` for details.

---

## Frontend Integration Guide
- Use the provided endpoint URLs in your React frontend (see `frontend_react/`).
- For REST endpoints, use `fetch` or `axios` to make requests.
- For WebSocket, use the browser's `WebSocket` API to connect to `/ws/live-meter` for real-time updates.
- All request/response bodies are documented above for easy integration.
- Example React code for WebSocket:
```js
const ws = new WebSocket('ws://localhost:8000/ws/live-meter');
ws.onmessage = (event) => {
  const data = JSON.parse(event.data);
  // Update dashboard with data
};
```
- Example React code for REST:
```js
fetch('http://localhost:8000/history/data?period=day')
  .then(res => res.json())
  .then(data => {
    // Use data.labels, data.kwh_data, data.cost_data
  });
```

---

## New Features

### Chat Endpoints

#### POST /chat/message
Chat with your energy data using LLM. Returns a context-aware response.
- **Request Body:**
```json
{ "message": "How can I save more on my bill?" }
```
- **Response:**
```json
{ "reply": "Based on your average load..." }
```

#### POST /chat/stream
Real-time streaming chat response (SSE). Returns response chunk by chunk.
- **Request Body:**
```json
{ "message": "What is my peak usage?" }
```
- **Response:**
```
(data: {"chunk": "B"}\n\n ... data: {"done": true}\n\n)
```

### PDF Report Generation

#### GET /report/generate-pdf
Download a comprehensive PDF report of your energy data.
- **Response:**
  - Content-Type: application/pdf
  - Attachment: energy_report.pdf

#### GET /report/download-enhanced
Get a JSON report with user data and LLM-generated insights.
- **Response:**
```json
{
  "user_data": { ... },
  "ai_insights": "- Reduce AC usage...\n- Switch to LED bulbs...",
  "generated_at": "2025-11-28T12:34:56.789Z",
  "period_days": 30
}
```

---

## Support
For any issues, contact the project maintainer or raise an issue in your repository.
