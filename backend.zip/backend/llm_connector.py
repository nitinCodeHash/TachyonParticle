from langchain_openai import ChatOpenAI
import os
import httpx
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()

# Get API key from environment
API_KEY = os.getenv("OPENAI_API_KEY")
BASE_URL = os.getenv("OPENAI_BASE_URL", "https://genailab.tcs.in")
MODEL = os.getenv("OPENAI_MODEL", "azure_ai/genailab-maas-DeepSeek-V3-0324")

client = httpx.Client(verify=False)

llm = ChatOpenAI(
    base_url=BASE_URL,
    model=MODEL,
    api_key=API_KEY,
    http_client=client
)

def llm_invoke(prompt: str):
    return llm.invoke(prompt)
