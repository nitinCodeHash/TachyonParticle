import sqlite3
from datetime import datetime, timedelta
import random
from typing import List, Tuple

DB_NAME = "energy.db"

MASTER_APPLIANCES_DATA: List[Tuple] = [
    ("Fridge", 150, 0.0, 20, 1),
    ("Microwave", 1200, 0.05, 5, 0),
    ("Dishwasher", 1200, 0.02, 45, 0),
    ("ElectricStove", 2000, 0.05, 30, 0),
    ("Toaster", 800, 0.03, 3, 0),
    ("CoffeeMaker", 1000, 0.04, 10, 0),
    ("Blender", 400, 0.02, 5, 0),
    ("Kettle", 1500, 0.05, 5, 0),
    ("RiceCooker", 700, 0.02, 30, 0),
    ("Juicer", 600, 0.01, 10, 0),
    ("FoodProcessor", 500, 0.01, 10, 0),
    ("InductionCooktop", 2000, 0.04, 30, 0),
    ("Chimney", 200, 0.04, 30, 0),
    ("WaterPurifier", 40, 0.0, 10, 1),
    ("SandwichMaker", 700, 0.02, 10, 0),
    ("AirFryer", 1500, 0.02, 20, 0),
    ("Oven", 2500, 0.01, 45, 0),
    ("MixerGrinder", 500, 0.03, 10, 0),
    ("AC", 1500, 0.05, 120, 0),
    ("Heater", 2000, 0.04, 60, 0),
    ("CeilingFan", 75, 0.2, 240, 0),
    ("TableFan", 50, 0.1, 120, 0),
    ("AirPurifier", 50, 0.1, 480, 0),
    ("Dehumidifier", 500, 0.05, 60, 0),
    ("Humidifier", 50, 0.05, 120, 0),
    ("WashingMachine", 500, 0.02, 45, 0),
    ("Dryer", 3000, 0.01, 45, 0),
    ("Geyser", 2000, 0.03, 20, 0),
    ("Iron", 1000, 0.02, 15, 0),
    ("VacuumCleaner", 1400, 0.01, 20, 0),
    ("TV", 120, 0.1, 120, 0),
    ("GamingPC", 450, 0.05, 180, 0),
    ("Laptop", 65, 0.2, 240, 0),
    ("Router", 10, 1.0, 1440, 1),
    ("HomeTheater", 100, 0.02, 120, 0),
    ("Projector", 300, 0.01, 120, 0),
    ("Printer", 50, 0.01, 5, 0),
    ("SetTopBox", 20, 0.1, 120, 0),
    ("SmartSpeaker", 10, 1.0, 1440, 1),
    ("LEDBulb", 10, 0.4, 300, 0),
    ("TubeLight", 20, 0.3, 300, 0),
    ("Chandelier", 100, 0.01, 180, 0),
    ("NightLamp", 2, 0.5, 480, 0),
    ("EV_Charger", 3500, 0.01, 240, 0),
    ("PoolPump", 1500, 0.01, 60, 1),
    ("HairDryer", 1600, 0.02, 10, 0),
    ("Treadmill", 1000, 0.01, 30, 0),
    ("AquariumPump", 20, 1.0, 1440, 1),
    ("SecurityCamera", 10, 1.0, 1440, 1),
    ("GarageDoor", 500, 0.01, 1, 0),
    ("SewingMachine", 100, 0.01, 60, 0),
    ("DrillMachine", 700, 0.005, 10, 0)
]


def init_db():
    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()

    # 1. Master Appliances
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS master_appliances (
            name TEXT PRIMARY KEY,
            watts INTEGER,
            probability REAL,
            duration_mins INTEGER,
            is_cyclic INTEGER
        )
    ''')
    cursor.execute('SELECT count(*) FROM master_appliances')
    if cursor.fetchone()[0] == 0:
        cursor.executemany('INSERT INTO master_appliances VALUES (?, ?, ?, ?, ?)', MASTER_APPLIANCES_DATA)

    # 2. User Config
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS user_config (
            user_id TEXT DEFAULT 'default_user',
            appliance_name TEXT,
            PRIMARY KEY (user_id, appliance_name)
        )
    ''')

    # 3. Leaderboard
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS leaderboard (
            user_id TEXT PRIMARY KEY,
            display_name TEXT,
            monthly_score INTEGER,
            is_bot INTEGER
        )
    ''')
    cursor.execute('SELECT count(*) FROM leaderboard')
    if cursor.fetchone()[0] == 0:
        fake_neighbors = [
            ("bot_1", "GreenGuru_99", 250, 1),
            ("bot_2", "SolarSteve", 180, 1),
            ("bot_3", "AverageJoe", 450, 1),
            ("bot_4", "PowerWaster_X", 600, 1),
            ("default_user", "You", 0, 0)
        ]
        cursor.executemany('INSERT INTO leaderboard VALUES (?, ?, ?, ?)', fake_neighbors)

    # 4. Action Tracking
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS action_log (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id TEXT DEFAULT 'default_user',
            action_title TEXT,
            timestamp TEXT,
            savings_inr REAL,
            status TEXT DEFAULT 'active'
        )
    ''')

    # 5. User Goals
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS user_goals (
            user_id TEXT PRIMARY KEY DEFAULT 'default_user',
            kw_limit_threshold REAL DEFAULT 5.0,  
            monthly_kwh_goal REAL DEFAULT 300.0
        )
    ''')
    cursor.execute("INSERT OR IGNORE INTO user_goals (user_id, kw_limit_threshold, monthly_kwh_goal) VALUES ('default_user', 5.0, 300.0)")

    # 6. Historical Data
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS consumption_history (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp TEXT,
            total_kw REAL,
            cost REAL,
            temperature REAL
        )
    ''')

    conn.commit()
    conn.close()


def seed_history():
    """Generates 90 days of fake history on startup so graphs aren't empty"""
    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()
    cursor.execute("SELECT count(*) FROM consumption_history")
    if cursor.fetchone()[0] > 0:
        conn.close()
        return # Already seeded

    print("🕰️ Seeding 3 months of historical data (this happens once)...")

    # Import simulator lazily to avoid circular imports
    from simulator import SmartHomeSimulator

    temp_sim = SmartHomeSimulator(seed_mode=True)

    history_data = []
    end_date = datetime.now()
    start_date = end_date - timedelta(days=90)

    current = start_date
    while current <= end_date:
        reading = temp_sim.simulate_historical_tick(current.hour)
        history_data.append((
            current.isoformat(),
            reading['total_kw'],
            reading['cost'],
            reading['temp']
        ))
        current += timedelta(hours=1)

    cursor.executemany('INSERT INTO consumption_history (timestamp, total_kw, cost, temperature) VALUES (?, ?, ?, ?)', history_data)
    conn.commit()
    conn.close()
    print("✅ History seeded.")
